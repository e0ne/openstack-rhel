The :mod:`nova..console.fake` Module
==============================================================================
.. automodule:: nova..console.fake
  :members:
  :undoc-members:
  :show-inheritance:
