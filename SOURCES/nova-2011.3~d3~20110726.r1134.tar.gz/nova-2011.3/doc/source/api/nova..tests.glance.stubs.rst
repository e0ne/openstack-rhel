The :mod:`nova..tests.glance.stubs` Module
==============================================================================
.. automodule:: nova..tests.glance.stubs
  :members:
  :undoc-members:
  :show-inheritance:
