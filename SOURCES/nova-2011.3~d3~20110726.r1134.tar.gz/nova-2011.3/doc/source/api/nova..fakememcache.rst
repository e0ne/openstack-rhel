The :mod:`nova..fakememcache` Module
==============================================================================
.. automodule:: nova..fakememcache
  :members:
  :undoc-members:
  :show-inheritance:
