The :mod:`nova..image.glance` Module
==============================================================================
.. automodule:: nova..image.glance
  :members:
  :undoc-members:
  :show-inheritance:
