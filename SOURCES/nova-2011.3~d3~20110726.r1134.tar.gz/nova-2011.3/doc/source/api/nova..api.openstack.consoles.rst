The :mod:`nova..api.openstack.consoles` Module
==============================================================================
.. automodule:: nova..api.openstack.consoles
  :members:
  :undoc-members:
  :show-inheritance:
