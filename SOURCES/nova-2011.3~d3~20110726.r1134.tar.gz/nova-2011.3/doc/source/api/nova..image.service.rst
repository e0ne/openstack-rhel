The :mod:`nova..image.service` Module
==============================================================================
.. automodule:: nova..image.service
  :members:
  :undoc-members:
  :show-inheritance:
