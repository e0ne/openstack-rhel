The :mod:`nova..compute.power_state` Module
==============================================================================
.. automodule:: nova..compute.power_state
  :members:
  :undoc-members:
  :show-inheritance:
