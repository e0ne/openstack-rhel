The :mod:`nova..auth.fakeldap` Module
==============================================================================
.. automodule:: nova..auth.fakeldap
  :members:
  :undoc-members:
  :show-inheritance:
