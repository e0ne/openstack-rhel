The :mod:`nova..db.sqlalchemy.migrate_repo.versions.007_add_instance_types` Module
==============================================================================
.. automodule:: nova..db.sqlalchemy.migrate_repo.versions.007_add_instance_types
  :members:
  :undoc-members:
  :show-inheritance:
