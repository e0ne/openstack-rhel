The :mod:`nova..api.ec2.admin` Module
==============================================================================
.. automodule:: nova..api.ec2.admin
  :members:
  :undoc-members:
  :show-inheritance:
