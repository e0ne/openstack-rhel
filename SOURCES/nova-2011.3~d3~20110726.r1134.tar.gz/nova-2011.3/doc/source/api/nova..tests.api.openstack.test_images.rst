The :mod:`nova..tests.api.openstack.test_images` Module
==============================================================================
.. automodule:: nova..tests.api.openstack.test_images
  :members:
  :undoc-members:
  :show-inheritance:
