The :mod:`nova..tests.api.openstack.test_adminapi` Module
==============================================================================
.. automodule:: nova..tests.api.openstack.test_adminapi
  :members:
  :undoc-members:
  :show-inheritance:
