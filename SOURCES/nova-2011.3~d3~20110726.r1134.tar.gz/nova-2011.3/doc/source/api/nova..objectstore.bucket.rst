The :mod:`nova..objectstore.bucket` Module
==============================================================================
.. automodule:: nova..objectstore.bucket
  :members:
  :undoc-members:
  :show-inheritance:
