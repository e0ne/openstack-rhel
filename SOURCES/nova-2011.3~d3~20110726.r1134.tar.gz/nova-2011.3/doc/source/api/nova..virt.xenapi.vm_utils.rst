The :mod:`nova..virt.xenapi.vm_utils` Module
==============================================================================
.. automodule:: nova..virt.xenapi.vm_utils
  :members:
  :undoc-members:
  :show-inheritance:
