The :mod:`nova..auth.signer` Module
==============================================================================
.. automodule:: nova..auth.signer
  :members:
  :undoc-members:
  :show-inheritance:
