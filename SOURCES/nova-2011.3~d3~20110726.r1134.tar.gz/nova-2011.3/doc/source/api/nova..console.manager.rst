The :mod:`nova..console.manager` Module
==============================================================================
.. automodule:: nova..console.manager
  :members:
  :undoc-members:
  :show-inheritance:
