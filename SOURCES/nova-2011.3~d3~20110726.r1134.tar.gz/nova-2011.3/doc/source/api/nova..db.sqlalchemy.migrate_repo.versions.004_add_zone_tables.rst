The :mod:`nova..db.sqlalchemy.migrate_repo.versions.004_add_zone_tables` Module
==============================================================================
.. automodule:: nova..db.sqlalchemy.migrate_repo.versions.004_add_zone_tables
  :members:
  :undoc-members:
  :show-inheritance:
