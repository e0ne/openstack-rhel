The :mod:`nova..scheduler.simple` Module
==============================================================================
.. automodule:: nova..scheduler.simple
  :members:
  :undoc-members:
  :show-inheritance:
