The :mod:`nova..image.local` Module
==============================================================================
.. automodule:: nova..image.local
  :members:
  :undoc-members:
  :show-inheritance:
