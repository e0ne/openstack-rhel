The :mod:`nova..api.openstack.shared_ip_groups` Module
==============================================================================
.. automodule:: nova..api.openstack.shared_ip_groups
  :members:
  :undoc-members:
  :show-inheritance:
