Live CD
=======

* 3 Images
* Once you start bundling images, must be able to point to source code
* Could make part of build

* sudo nova-manage user admin newuser
* sudo nova-manage project create demo newuser
* sudo nova-manage project zipfile demo
* get images
* Web browser
